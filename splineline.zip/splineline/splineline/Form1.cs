﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ScottPlot;
using ScottPlot.Statistics.Interpolation;

namespace splineline
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //x-axis values
            double[] xs = new double[] {0,-0.20183804128404614,0.589960890165512,0.22836676762828922,1.1218418353804582,0.8007138845514106,1.6982703663866363,2.314254146681286,2.355716040523591,2.6436321687156488,2.2687500651314627,2.103505594238409,2.8413856983377537,3.7359170935749626,3.664945382468843,4.159812492858531,4.538118526590112,4.709043946912998,3.858077279225959,3.0221530841766637
};
            //y-axis values
            double[] ys = new double[] {0,-0.7491666421988823,-0.190862492747075,-0.003789370415633986,0.08438053824211522,-0.6647388877648572,-0.38675406406948043,-0.9585159532532633,-0.19054800467125477,-0.62286290788225,-0.8355579100714797,-0.045868142994990424,0.45904736335344987,0.45373871338262195,0.49003162257840505,1.3414179945091806,1.3996559127232326,0.8838081247563518,0.31068433370007464,0.011776051023871359
};
            //make spline line
            (double[] smoothxs, double[] smoothys) = Cubic.InterpolateXY(xs, ys, 50);
            //draw normal
            formsPlot1.Plot.AddScatter(xs, ys, Color.Green, markerSize: 10, lineWidth: 1, label: "orignial line");

            //draw spline line
            formsPlot1.Plot.AddScatter(smoothxs, smoothys, Color.Magenta, label: "spline line");
            //show legrnd
            formsPlot1.Plot.Legend();
            //refreshed
            formsPlot1.Refresh();
        }
    }
}
